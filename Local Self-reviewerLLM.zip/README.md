# Question-Answering Agent with Tool Calling (Local LLM)

A full-stack application featuring a local LLM-powered chatbot with tool calling capabilities, an evaluation system, and a web dashboard for interaction and analysis.

## 🎯 Project Overview

This project implements:

1. **Local LLM Chatbot**: A conversational agent powered by Llama-3 (running locally via `llama-cpp-python`) that can use external tools (web search, calculator).
2. **Evaluation System**: An LLM-as-judge evaluation framework to measure chatbot quality.
3. **Web Dashboard**: A React-based interface for chatting and viewing evaluation results.

## 📁 Project Structure

```
qa-agent/
├── backend/
│   ├── agent.py          # Core chatbot logic with tool calling and local LLM
│   ├── server.py         # FastAPI REST API server
│   ├── evaluation.py     # Evaluation dataset and LLM-as-judge
│   ├── setup_local.py    # Script to download the Llama model
│   └── requirements.txt  # Python dependencies
├── frontend/
│   └── index.html        # React dashboard (single-file app)
└── README.md
```

## 🚀 Quick Start

### Prerequisites

- Python 3.9+
- 8GB+ RAM recommended (for running the 3B model)
- C++ Compiler (Visual Studio Build Tools on Windows, Xcode on Mac, GCC on Linux) for building `llama-cpp-python`

### 1. Set up the Backend

```bash
cd backend

# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Download the Local Model (approx 2GB)
python setup_local.py

# Run the server
python server.py
```

The API will be available at `http://localhost:8000`

### 2. Open the Frontend

Simply open `frontend/index.html` in a web browser, or serve it:

```bash
# Using Python's built-in server
cd frontend
python -m http.server 3000
# Then open http://localhost:3000
```

## 🔧 How It Works

### Local LLM Architecture

```
User Question → Llama-3 (Local) → Tool Call Decision (JSON)
                                     ↓
                             [Execute Tool] ← Tool Result
                                     ↓
                          Llama-3 → Final Response
```

1. **User sends a question** to the chatbot
2. **Llama receives** the question along with available tool definitions in the system prompt
3. **Llama decides** whether to call a tool by outputting a JSON object
4. **Agent executes the tool** and feeds the result back to Llama
5. **Llama generates** the final response

### Available Tools

| Tool | Description | Use Case |
|------|-------------|----------|
| `web_search` | Searches the web for information | Current events, real-time data |
| `calculator` | Performs mathematical calculations | Arithmetic, percentages, unit conversions |

### Evaluation Methodology

The evaluation uses an **LLM-as-judge** approach with the local model:

1. **Dataset**: 10 test questions across categories (calculation, factual, search, reasoning)
2. **Execution**: Each question is run through the chatbot
3. **Judging**: Llama evaluates responses on correctness, completeness, and relevance
4. **Metrics**: Results are aggregated into accuracy, average score, and tool usage statistics

## 📊 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Health check |
| `/chat` | POST | Send message, get response |
| `/evaluate` | POST | Run evaluation suite |
| `/evaluation-results` | GET | Get latest results |
| `/session/{id}` | DELETE | Clear a conversation |

## 🧪 Running Evaluations

### Via Command Line

```bash
cd backend
python evaluation.py
```

## 📝 Design Decisions

1. **Llama-3 as the LLM**: Chosen for its efficiency and instruction-following capabilities, making it suitable for local execution on consumer hardware.
2. **llama-cpp-python**: Used for running GGUF models efficiently.
3. **LLM-as-judge**: Reused the same local model for evaluation to keep the system self-contained.

## 📄 License

MIT License - feel free to use and modify as needed.
